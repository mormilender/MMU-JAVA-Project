package com.hit.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;

import com.hit.dm.DataModel;

public class DaoFileImpl <T> implements IDao<java.lang.Long,DataModel<T>>{

	HashMap<Long,DataModel<T>> maper ;//hard disk memory
	String filePath;
	int capacity;


	public DaoFileImpl(java.lang.String filePath,int capacity)
	{
		this.capacity=capacity;
		this.filePath=filePath;

		//File file=null;
		FileOutputStream foutput=null;
		ObjectOutputStream output=null;
		FileInputStream finput=null;
		ObjectInputStream input=null;
		try {
			foutput=new FileOutputStream(this.filePath,true);
			finput = new FileInputStream(this.filePath);
			output=new ObjectOutputStream(foutput);
			input = new ObjectInputStream(finput);
			//reading from file
			HashMap<Long,DataModel<T>> tempmaper = (HashMap<Long, DataModel<T>>) input.readObject();
			if(tempmaper.size()>capacity)
			{
				System.out.println("not enough mamory");//if size of file too big for capacity
				maper=new HashMap<Long, DataModel<T>>();
			}
			else {
				maper = tempmaper;
			}

		}
		catch( IOException e)
		{
			maper=new HashMap<Long, DataModel<T>>();
			System.out.println("harddrive is empty");
			//e.printStackTrace();
		}
		catch( ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		finally {//close streams
			try {
				input.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			finally {
				try {
					finput.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
				try {
					output.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
				finally {
					try {
						foutput.close();
					} catch (IOException e) {
						e.printStackTrace();
					}

				}


			}
		}


	}

	@SuppressWarnings("unchecked")
	public DaoFileImpl(String filePath) {

		this.capacity=-1;//flag - no capacity
		this.filePath=filePath;

		//File file=null;
		FileInputStream finput=null;
		ObjectInputStream input=null;
		FileOutputStream foutput=null;
		ObjectOutputStream output=null;


		try {//open streams
			foutput=new FileOutputStream(this.filePath,true);
			finput = new FileInputStream(this.filePath);
			output=new ObjectOutputStream(foutput);
			input = new ObjectInputStream(finput);
			maper = (HashMap<Long, DataModel<T>>) input.readObject();

		}
		catch( IOException e)
		{
			maper=new HashMap<Long, DataModel<T>>();
			System.out.println("harddrive is empty");
			//e.printStackTrace();
		}
		catch( ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		finally {//close streams
			try {
				input.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			finally {
				try {
					finput.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
				try {
					output.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
				finally {
					try {
						foutput.close();
					} catch (IOException e) {
						e.printStackTrace();
					}

				}


			}
		}

	}	


	@Override
	public void delete(DataModel<T> entity)  //removing wanted data from hard drive and updating file
	{

		if(entity!=null)
		{
			maper.remove(entity.getDataModelId());

			FileOutputStream foutput=null;
			ObjectOutputStream output=null;

			try {
				//open stream
			
				foutput=new FileOutputStream(this.filePath);
				output=new ObjectOutputStream(foutput);
				output.writeObject(maper);
				output.flush();
			}
			catch (FileNotFoundException e) {
				e.printStackTrace();
			}catch(IOException e)
			{
				e.printStackTrace();
			}
			finally {//close streams

				try {
					foutput.close();
				} catch (IOException e) {
					e.printStackTrace();
				}finally {
					try {
						output.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}







	@Override
	public DataModel<T> find(Long id) //returns data with matching id from hard drive
	{
		DataModel dmodels = null;
		if (maper.containsKey(id))
			dmodels = new DataModel<>(id,maper.get(id).getContent());
		return dmodels;

	}

	@Override
	public void save(DataModel<T> entity) //saving data to hard disk and update file
	{
		if(maper.size()>=capacity && capacity!=-1)
		{
			System.out.println("not enough memory");
		}
		else {

			if(entity!=null)
			{
				maper.put(entity.getDataModelId(),entity);
				FileOutputStream foutput=null;
				ObjectOutputStream output=null;

				try {
					//open stream
					foutput=new FileOutputStream(this.filePath);
					output=new ObjectOutputStream(foutput);
					output.writeObject(maper);
					output.flush();

				} catch (FileNotFoundException e) {
					e.printStackTrace();
				}catch(IOException e)
				{
					e.printStackTrace();
				}
				finally {//close streams
					try {
						foutput.close();
					} catch (IOException e) {
						e.printStackTrace();
					}finally {
						try {
							output.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
					}

				}

			}
		}
	}
}


