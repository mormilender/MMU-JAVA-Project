package com.hit.model;

public interface Model {

	<T> void updateModelData(T t);
}
