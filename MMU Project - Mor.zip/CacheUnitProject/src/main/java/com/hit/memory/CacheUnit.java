package com.hit.memory;



import java.util.concurrent.atomic.AtomicInteger;

import com.hit.algorithm.IAlgoCache;
import com.hit.dao.IDao;
import com.hit.dm.DataModel;

public class CacheUnit<T> extends java.lang.Object
{

	public IAlgoCache<java.lang.Long,DataModel<T>> algorithm;
	IDao<java.io.Serializable,DataModel<T>> dao;
	public AtomicInteger swap;
	public static AtomicInteger taken=new AtomicInteger(0);
	
	public CacheUnit(IAlgoCache<java.lang.Long,DataModel<T>> algorithm, IDao<java.io.Serializable,DataModel<T>> dao) 
	{
		this.algorithm = algorithm;
		this.dao = dao;
		swap=new AtomicInteger(0);
		
	}

	public DataModel<T>[] putDataModels(DataModel<T>[] datamodels)//saves data to cache
	{
	
		DataModel<T> [] models=new DataModel[datamodels.length];
	

		for(int i=0;i<datamodels.length;i++) 
		{
	
			DataModel<T> datacache=this.algorithm.getElement(datamodels[i].getDataModelId());
			if(datacache==null)//if not in cache
			{
					dao.delete(datamodels[i]);//delete from harddrive if in there
					DataModel<T> replaceval=this.algorithm.putElement(datamodels[i].getDataModelId(),datamodels[i]);//puts in cache
					if(replaceval!=null)//save replaced data from cache to hard disk
					{
						models[i]=replaceval;
						dao.save(replaceval);
						swap.incrementAndGet();

					}
					else 
					{
						taken.incrementAndGet();
						models[i]=null;
					}
					
			}
			else {
				this.algorithm.removeElement(datamodels[i].getDataModelId());//removes from cache
				this.algorithm.putElement(datamodels[i].getDataModelId(),datamodels[i]);//puts updated dm in cache
			}
			
				
		}

		return models;//return data that was replaced in cache

	}

	public DataModel<T>[] getDataModels(java.lang.Long[] ids)	//gets data from cache or from hard drive
	{
		DataModel<T> [] models=new DataModel[ids.length];


		for(int i=0;i<ids.length;i++)  
		{
			DataModel<T> datacache=this.algorithm.getElement(ids[i]);//checks for DataModel in the cache
			if(datacache==null)//not in cache
			{
				DataModel<T> datafile=this.dao.find(ids[i]);//find in hard disk
				if(datafile!=null)
				{
					models[i]=datafile;
					DataModel<T> replaceval=this.algorithm.putElement(datafile.getDataModelId(),datafile);
					dao.delete(datafile);
					if(replaceval!=null)//save replaced data in hard drive
					{
						dao.save(replaceval);
						swap.incrementAndGet();
					}
					else {
						taken.incrementAndGet();
					}
					
				}
				else models[i]=null;//not in hard disk
			}
			else models[i]=datacache;//in cache
		}
	
		return models;

	}

	public void removeDataModels(java.lang.Long[] ids)//deletes data from cache and hard drive
	{

		for(int i=0;i<ids.length;i++) 
		{
			if(this.algorithm.getElement(ids[i])!=null)
			{
				this.algorithm.removeElement(ids[i]);//removes from cache
				if(this.algorithm.getElement(ids[i])==null)
				{
					taken.decrementAndGet();
				}
			}
			DataModel<T> datafile=this.dao.find(ids[i]);//find in file 
			if(datafile!=null)
				this.dao.delete(datafile);//removes from hard disk
			
		}

	}

}