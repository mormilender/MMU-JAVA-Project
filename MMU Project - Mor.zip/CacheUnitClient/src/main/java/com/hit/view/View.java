package com.hit.view;

public interface View {

	void start();
	<T> void updateUIData(T t);
}
