package com.hit.memory;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.HashMap;

import org.junit.jupiter.api.Test;

import com.hit.algorithm.IAlgoCache;
import com.hit.algorithm.LRUAlgoCacheImpl;
import com.hit.dao.DaoFileImpl;
import com.hit.dao.IDao;
import com.hit.dm.DataModel;

public class CacheUnitTest {

	@Test
	void getDataModelsTest() throws IOException 
	{
		HashMap<Long,DataModel<String>> maper = new HashMap<Long, DataModel<String>>();
        DataModel modelData1 = new DataModel((long)1,'A');maper.put((long)1,modelData1);
        DataModel modelData2 = new DataModel((long)2,'B');maper.put((long)2,modelData2);
        DataModel modelData3 = new DataModel((long)3,'C');maper.put((long)3,modelData3);
        DataModel modelData4 = new DataModel((long)4,'D');maper.put((long)4,modelData4);
        DataModel modelData5 = new DataModel((long)5,'E');maper.put((long)5,modelData5);
        DataModel modelData6 = new DataModel((long)6,'F');maper.put((long)6,modelData6);
        DataModel modelData7 = new DataModel((long)7,'G');maper.put((long)7,modelData7);
        
        File TheFile=new File("tester.dat"); 
        FileOutputStream fos=new FileOutputStream(TheFile);
        ObjectOutputStream oos=new ObjectOutputStream(fos);
        oos.writeObject(maper);
        oos.flush();
        oos.close();
        fos.close();
        
        IAlgoCache <Long,String> algo = null; 
        algo = new LRUAlgoCacheImpl<Long,String>(3);
        IDao dao = null;
        dao = new DaoFileImpl<String>("tester.dat");
        
        CacheUnit<String> CU = new CacheUnit(algo,dao);
        Long[] idds = new Long[]{(long) 3,(long) 5,(long) 2};
        DataModel[] DMs = CU.getDataModels(idds);
       
        for(int i=0;i<DMs.length;i++)
        {
        	System.out.println("elemnt: " + DMs[i].getContent() + "\n ---------------- \n");
        	
        }
        CU.removeDataModels(idds);
        DataModel[] DMs1 = CU.getDataModels(idds);
        for(int i=0;i<DMs1.length;i++)
        {
        	System.out.println("elemnt: " + DMs1[i]+ "\n ---------------- \n");
        	
        }
        CU.putDataModels(DMs);
        DataModel[] DMs2 = CU.getDataModels(idds);
        
        for(int i=0;i<DMs2.length;i++)
        {
        	System.out.println("elemnt: " + DMs2[i].getContent() + "\n ---------------- \n");
        	
        }
        
        
	}
}
