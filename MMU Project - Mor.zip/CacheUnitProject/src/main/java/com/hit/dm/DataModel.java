package com.hit.dm;

public class DataModel<T> extends java.lang.Object implements java.io.Serializable {
	
	
	java.lang.Long dataModelId;
	T content;
	
	
	public DataModel(java.lang.Long id, T content) 
	{
		this.content=content;
		this.dataModelId=id;
		
	}
	
	public boolean equals(java.lang.Object obj) 
	{
		return false;
	}
	
	public T getContent()
	{
		return content;
	}
	public java.lang.Long getDataModelId()
	{
		return dataModelId;
	}
	public void	setContent(T content)
	{
		this.content = content;
	} 
	
	public void	setDataModelId(java.lang.Long id)
	{
		this.dataModelId = id;
	} 
	public int	hashCode()
	{
		return 0;
	}
	
	public java.lang.String	toString() 
	{
		return Long.toString(dataModelId);
	}

}