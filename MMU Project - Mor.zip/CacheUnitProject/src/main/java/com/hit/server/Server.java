package com.hit.server;


import com.hit.algorithm.IAlgoCache;
import com.hit.algorithm.LRUAlgoCacheImpl;
import com.hit.algorithm.RandomAlgoCacheImpl;
import com.hit.algorithm.SecondChance;
import com.hit.dm.DataModel;
import com.hit.services.CacheUnitController;

import java.beans.PropertyChangeEvent;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Observable;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

public class Server extends java.lang.Object implements java.beans.PropertyChangeListener, java.lang.Runnable {

	ServerSocket SSocket; 
	ThreadPoolExecutor threadPoolExecutor;
	int port;
	int cap=-1;
	IAlgoCache<Long, DataModel<String>> algo=null;
	int thread_num=5;
	boolean Is_Running=false; 

	public Server(int port) {
		this.port=port;
		threadPoolExecutor = (ThreadPoolExecutor) Executors.newFixedThreadPool(thread_num);//creates threadpool for requests
	}

	@Override
	public void run() {//opens connection with socket and creates request handler 

		try {
			SSocket = new ServerSocket(port);
		} catch (IOException e1) {
			e1.printStackTrace();
		}


		while (Is_Running) {

			Socket Connected=null;
			try {
				Connected = SSocket.accept();
				HandleRequest<String> RequesterHandler = new HandleRequest<String>(Connected, new CacheUnitController<String>(algo,cap));  //creating request handler
				threadPoolExecutor.execute(RequesterHandler);//starting request handler

			} catch (IOException e) {

				try {
					if(Connected!=null)
						Connected.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}

		}
	}

	@Override
	public void propertyChange(java.beans.PropertyChangeEvent evt)  {//get change event from who server listens to and act according to event

		String event=(String) evt.getPropertyName();
		if(event.equals("state"))
		{
			if(evt.getNewValue().equals("shut_down"))//to shutdown server
			{
				if(Is_Running == false)
					System.out.println("Server Is Already In Shutdown!!!");
				else {
					Is_Running = false;
					while(threadPoolExecutor.getActiveCount()>0){} //waits for all threads to close
					try {
						SSocket.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					threadPoolExecutor.shutdown();
					System.out.println("Server Is Now In Shutdown!!!");

				}

			}
			if(evt.getNewValue().equals("start"))//to start server
			{
				Is_Running = true;
				if ((SSocket == null)||(SSocket.isClosed())) //if server isn't running start
				{
					if(algo==null || cap<0)//Default configuration
					{
						cap=5;
						algo=new LRUAlgoCacheImpl<>(cap);
					}
					System.out.println("Server Started");
					new Thread(this).start();//start server 
				}
				else
					System.out.println("Server Is Already Running");
			}

		}
		else
		{
			if(event.equals("configuring"))//to configure server
			{
				//checks which algorithm and capacity where chosen and saves them

				String algorithm=(String) evt.getOldValue();
				try {
					cap=Integer.parseInt((String) evt.getNewValue());
				}
				catch(Exception e)
				{
					cap=-1;
				}
				if(cap<0)cap=5;//Default in case of invalid capacity 

				switch(algorithm)
				{
				case "lru":
					algo=new LRUAlgoCacheImpl<>(cap);
					break;
				case "random":
					algo=new RandomAlgoCacheImpl<>(cap);	
					break;
				case "secondchance":
					algo=new SecondChance<>(cap);
					break;
				}
			}
		}
	}
}	

