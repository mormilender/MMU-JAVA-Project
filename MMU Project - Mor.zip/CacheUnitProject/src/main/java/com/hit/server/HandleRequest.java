package com.hit.server;

import java.net.Socket;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.hit.dm.DataModel;
import com.hit.memory.CacheUnit;
import com.hit.services.CacheUnitController;



import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Reader;
import java.lang.reflect.Type;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;


public class HandleRequest<T> extends java.lang.Object implements java.lang.Runnable{
	Socket socket; 
	CacheUnitController<T> control; 


	public HandleRequest(java.net.Socket socket,CacheUnitController<T> control){
		this.socket=socket;
		this.control=control;
	}

	@Override
	public void run() {
		//creates streams of input and output with socket
		ObjectInputStream input=null;
		ObjectOutputStream output=null;
		Request<DataModel<T>[]> request=null;
		Map<String, String> head=null;
		String act=null;
		DataModel<T> [ ] dm=null;
		try { //reading requests from Json file
			output=new ObjectOutputStream(socket.getOutputStream());
			input=new ObjectInputStream(socket.getInputStream());

			String s=(String)input.readObject();
			if(s.equals("STATISTICS"))
			{
				act=s;
			}
			else {
				Reader f=new FileReader(s);
				Type reference = new TypeToken<Request<DataModel<T>[]>>(){}.getType();  
				request = new Gson().fromJson(f, reference);
				head = request.getHeaders(); 
				act = head.get("action");
				dm=(DataModel<T>[])request.getBody();}



		} catch (IOException e1) {
			e1.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}



		

		String ans=null;

		//operating chosen action and returns response;

		switch (act)//action type
		{
		case "DELETE":
		{

			if(control.delete(dm))
				ans= "Succeeded";
			else ans= "Failed";
			
			head.put("get",control.cunit.get.toString());
			head.put("swap",control.cunit.CU.swap.toString());
		

			Response<String> response = new Response<String>(head,ans);
			try {
				output.writeObject(response);
				output.flush();
			} catch (IOException e) {
				e.printStackTrace();
			}

			break;
		}
		case "GET":
		{
			DataModel<T>[] data=(DataModel<T>[])control.get(dm);

			int size=0;
			if(data!=null)size=data.length;
			
			for(int i=0;i<size;i++)
			{
				if(ans!=null)
				{
					if(data[i]==null)
						ans+=", null";
					else ans+=", "+data[i].getDataModelId();
				}
				else {
					if(data[i]==null)
						ans="null";
					else ans=data[i].getDataModelId()+"";
				}
			}
			
			head.put("get",control.cunit.get.toString());
			head.put("swap",control.cunit.CU.swap.toString());
			Response<String> response=new Response<String>(head,ans);
			try {
				output.writeObject(response);
				output.flush();
			} catch (IOException e) {
				e.printStackTrace();
			}

			break;
		}
		case "UPDATE":
		{

			if(control.update(dm)) 
				ans= "Succeeded";
			else ans= "Failed";
			
			
			head.put("get",control.cunit.get.toString());
			head.put("swap",control.cunit.CU.swap.toString());
			Response<String> response = new Response<String>(head,ans);
			try {
				output.writeObject(response);
				output.flush();
			} catch (IOException e) {
				e.printStackTrace();
			}

			break;
		}
		case "STATISTICS":

			Map<String, String> action=new HashMap<String, String>();
			action.put("action", "STATISTICS");
			action.put("cap",control.cunit.cap+"");
			int i=control.cunit.cap-CacheUnit.taken.intValue();
			action.put("ava",i+"");
			Response<String> response = new Response<String>(action,ans);
			try {
				output.writeObject(response);
				output.flush();
			} catch (IOException e) {
				e.printStackTrace();
			}
			break;
		}

		try {
			input.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			try {
				output.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}
}