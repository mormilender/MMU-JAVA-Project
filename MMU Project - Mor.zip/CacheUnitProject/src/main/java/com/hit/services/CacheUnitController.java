package com.hit.services;



import com.hit.algorithm.IAlgoCache;
import com.hit.dm.DataModel;

public class CacheUnitController<T> extends java.lang.Object
{
	public CacheUnitService<T> cunit;
	
	
  
	public CacheUnitController(IAlgoCache<Long, DataModel<T>> algo, int cap) {
		// TODO Auto-generated constructor stub
		cunit=new CacheUnitService<T>(algo,cap);
	}



	public boolean update(DataModel<T>[] dataModels){
        return cunit.update(dataModels);
    }
    public boolean delete(DataModel<T>[] dataModels){
        return cunit.delete(dataModels);
    }
    public DataModel<T>[] get(DataModel<T>[] dataModels){
        return cunit.get(dataModels);
    }
}
