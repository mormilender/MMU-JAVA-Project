package com.hit.model;

public class CacheUnitModel extends java.util.Observable implements Model{

	public CacheUnitClient client;
	public CacheUnitModel()
	{
		client=new CacheUnitClient();
	}
	@Override
	public <T> void updateModelData(T t) {
		setChanged();
		notifyObservers(client.send((String)t));
	}

}
