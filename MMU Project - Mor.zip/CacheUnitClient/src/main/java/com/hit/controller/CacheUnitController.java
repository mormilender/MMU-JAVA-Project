package com.hit.controller;

import java.awt.event.ActionEvent;
import java.util.Observable;

import com.hit.model.CacheUnitModel;
import com.hit.model.Model;
import com.hit.view.View;

public class CacheUnitController extends java.lang.Object implements Controller{
	
	private View view;
	private CacheUnitModel model;

	public CacheUnitController(Model model, View view) 
	{
		this.model=(CacheUnitModel)model;
		this.view=view;
	}
	
	
	@Override
	
	public void update(Observable obs, Object obj) {

		if(obs instanceof View)
			model.updateModelData(obj); //obj=request
		else if(obs instanceof Model)
		{
			view.updateUIData(obj); //obj=string response
		}
		
	}

}
