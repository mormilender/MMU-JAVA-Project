package com.hit.util;

import java.beans.PropertyChangeSupport;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Observable;
import java.util.Scanner;

import com.hit.server.Server;

public class CLI extends java.lang.Object implements java.lang.Runnable
{
	InputStream in;
	OutputStream out;
	Scanner reader;
	final PropertyChangeSupport support = new PropertyChangeSupport(this);


	public CLI(InputStream in , OutputStream out)
	{
		reader = new Scanner(new InputStreamReader(in));
		this.in = in;
		this.out = out;
	}
	
	void write(java.lang.String string) //print actions to user
	{
		System.out.println(string);
	}

	public void addPropertyChangeListener(java.beans.PropertyChangeListener listener)//adds listener
	{
		support.addPropertyChangeListener(listener);

	}

	public void removePropertyChangeListener(java.beans.PropertyChangeListener listener) //removes listener
	{
		support.removePropertyChangeListener(listener);

	}


	@Override
	public void run()
	{

		String UserInput;
		while (true)
		{
			System.out.println("Please enter Command:");
			UserInput = reader.nextLine().toLowerCase();
			switch (UserInput)
			{
			case "shutdown"://shutdown server
			{
				write("shutdown server");
				support.firePropertyChange("state", null, "shut_down");//update listeners
				break;
			}
			case "start"://start server
			{
				write("starting server...");
				support.firePropertyChange("state", null, "start");//update listeners
				break;
			}
			default:
			{
				String [] arr=UserInput.split(" ");
				
				if(arr[0].equals("cache_unit_config") && arr.length==3)//update listeners with algorithm and capacity
				{
					if(arr[1].equals("lru") || arr[1].equals("secondchance") || arr[1].equals("random") )
					{
						write(arr[1]+" "+arr[2]+" configured successfully");
						support.firePropertyChange("configuring", arr[1], arr[2]);
					}
					else write("not a valid comment");	
				}
				else write("not a valid comment");
				
				break;
			}

			}

		}

	}

}