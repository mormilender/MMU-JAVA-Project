package com.hit.model;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.HashMap;

import com.hit.server.Response;

public class CacheUnitClient extends java.lang.Object{


	String cap,ava;
	int get,swap;
	public CacheUnitClient()
	{
		cap="0";
		ava="0";
		get=0;
		swap=0;
	}


	public String send(String request)
	{
		Socket myServer=null;
		InetAddress add;

		try 
		{
			add=InetAddress.getLocalHost();
			myServer=new Socket(add,34567);

		}
		catch(IOException e) {
			e.printStackTrace();
		}

		ObjectInputStream input=null;
		ObjectOutputStream output=null;
		String msg=null;
		Response <String> response=null;


		try {
			output=new ObjectOutputStream(myServer.getOutputStream());
			input=new ObjectInputStream(myServer.getInputStream());
			output.writeObject(request);
			response=(Response<String>)input.readObject();
			if(response.getHeaders().get("action").equals("STATISTICS"))
			{
				cap=response.getHeaders().get("cap");
				ava=response.getHeaders().get("ava");
		
				msg="CacheMemory Info:\nCapacity: "+cap+"\nAvailable: "+ava+"\nNumber Of Get Actions: "+
						get+"\nNumber Of Swap Actions: "+swap;
			}
			else {
				swap+=Integer.parseInt(response.getHeaders().get("swap"));
				get+=Integer.parseInt(response.getHeaders().get("get"));
				msg="Action: "+ response.getHeaders().get("action")+" "+response.getBody();

			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			try {
				output.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally {
				try {
					input.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				finally {
					try {
						myServer.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

			}
		}
		return msg;
	}
}
