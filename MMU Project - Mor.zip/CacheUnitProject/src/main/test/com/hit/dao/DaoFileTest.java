package com.hit.dao;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.HashMap;

import org.junit.jupiter.api.Test;

import com.hit.algorithm.IAlgoCache;
import com.hit.algorithm.LRUAlgoCacheImpl;
import com.hit.dm.DataModel;
import com.hit.memory.CacheUnit;

public class DaoFileTest {

	@Test
	void Dao_File_Test() throws ClassNotFoundException, IOException 
	{
		HashMap<Long,DataModel<String>> Mymap = new HashMap<Long, DataModel<String>>();

		DataModel modelData1 = new DataModel((long)1,'a');
		Mymap.put((long)1,modelData1);

		DataModel modelData2 = new DataModel((long)2,'b');
		Mymap.put((long)2,modelData2);

		DataModel modelData3 = new DataModel((long)3,'c');
		Mymap.put((long)3,modelData3);

		DataModel modelData4 = new DataModel((long)4,'d');
		Mymap.put((long)4,modelData4);

		DataModel modelData5 = new DataModel((long)5,'e');
		Mymap.put((long)5,modelData5);


		File TheFile=new File("./src/main/resources/datasource.txt"); 

		ObjectOutputStream oos;

		oos = new ObjectOutputStream(new FileOutputStream(TheFile));
		oos.writeObject(Mymap);
		oos.flush();
		oos.close();


		DaoFileImpl dao = null;
		dao = new DaoFileImpl<String>("./src/main/resources/datasource.txt");


		DataModel modelData8=dao.find((long)2);
		System.out.println("find model data 2 :"+ modelData8.getDataModelId()+" - "+ modelData8.getContent() );


		dao.delete(modelData2);
		System.out.println("delete model data  "+  dao.find((long)2)) ;
		System.out.println("delete model data  "+  modelData2) ;

		DataModel modelData9=dao.find((long)2);


		System.out.println("find model data 2 "+ modelData9 );

		dao.save(modelData2);
		System.out.println("save model data 2 : "+ modelData2+" - "+modelData2.getContent());
		modelData8=dao.find((long)2);
		System.out.println("find model data 2 :"+ modelData8.getDataModelId()+" - "+ modelData8.getContent() );
	}     

}
