package com.hit.services;



import java.util.concurrent.atomic.AtomicInteger;

import com.hit.algorithm.AbstractAlgoCache;
import com.hit.algorithm.IAlgoCache;
import com.hit.algorithm.LRUAlgoCacheImpl;
import com.hit.algorithm.RandomAlgoCacheImpl;
import com.hit.algorithm.SecondChance;
import com.hit.dao.DaoFileImpl;
import com.hit.dao.IDao;
import com.hit.dm.DataModel;

public class CacheUnitService<T>{
	
	public com.hit.memory.CacheUnit<T> CU;
	public int cap;
	public AtomicInteger get;

	
	
    public CacheUnitService(IAlgoCache<Long, DataModel<T>> algo,int capacity) //builds cache unit with algorithm and capacity
    {
    	
    	cap=capacity;
    	get=new AtomicInteger(0);
        IDao<Long, DataModel<T>> dao = new DaoFileImpl<>("./src/main/resources/datasource.txt");
        CU = new com.hit.memory.CacheUnit(algo, dao);
       
       
        
    }
    public boolean delete(DataModel<T>[] dataModels) 
	{
    	if (dataModels==null)return true;
    	
		Long [] ids = new Long[dataModels.length];
		for(int i=0;i<dataModels.length;i++)
		{//create list of id's
			ids[i]=dataModels[i].getDataModelId();
		}
		CU.removeDataModels(ids);//deletes from memory
		DataModel<T> [] models =CU.getDataModels(ids);//try to find them in memory
	 	int count=0;
	 	
		for(int i=0;i<dataModels.length;i++)
		{
			if(models[i]==null)
				count++;
		}
		
		if(count==dataModels.length)return true;//all data was deleted - true
		else return false;//error in deleting - false
	}
    
	public DataModel<T>[] get(DataModel<T>[] dataModels) 
	{
		if (dataModels==null)return null;
		Long [] ids = new Long[dataModels.length];
		
		for(int i=0;i<dataModels.length;i++)//create list of id's
			ids[i]=dataModels[i].getDataModelId();
		
		DataModel<T> [] Data =CU.getDataModels(ids);//finds in memory and returns
		
		for(int i=0;i<Data.length;i++)
			if(Data[i]!=null)get.incrementAndGet();
	
		
		return Data;
	}
	
	public boolean update(DataModel<T>[] dataModels) 
	{
		
		if (dataModels==null)return true;
		
		DataModel<T>[] replaced=CU.putDataModels(dataModels);//puts in memory and returns the data that was removed from cache
	
		Long [] ids = new Long[dataModels.length];
		
		for(int i=0;i<dataModels.length;i++)//create list of id's
			ids[i]=dataModels[i].getDataModelId();
	
		DataModel<T> [] models =CU.getDataModels(ids);//find in memory
		for(int i=0;i<dataModels.length;i++)
		{
			if(models[i]==null)//false if data is missing from memory
				return false;
		}
		return true;//all data was added to memory
		
	}
}
