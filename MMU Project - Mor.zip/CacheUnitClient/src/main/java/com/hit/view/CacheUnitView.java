package com.hit.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.filechooser.FileSystemView;

public class CacheUnitView extends java.util.Observable implements View {
	public JTextArea infoArea;

	public CacheUnitView()
	{
		infoArea=new JTextArea();
	}

	@Override
	public void start() {
		JFrame frame=new JFrame();
		frame.setResizable(false);
		frame.setBounds(0,0,1000,600);

		Font f=new Font("Arial",Font.BOLD,15);
		Font f2=new Font("Arial",Font.BOLD,20);
		Color  mycolor   = new Color(62, 196, 196);
		Color  mycolor2   = new Color(210, 244, 244);
		Color  mycolor3   = new Color(43, 68, 109);


		JPanel ContentPane=new JPanel();
		ContentPane.setBackground(Color.BLACK);
		frame.setContentPane(ContentPane);
		ContentPane.setLayout(null);

		JPanel ipanel=new JPanel();
		ipanel.setBounds(0,0,1000,300);
		ipanel.setBackground(Color.DARK_GRAY);
		ContentPane.add(ipanel);
		ipanel.setLayout(null);

		JLabel image=new JLabel("");
		image.setBounds(0,0,1000,300);
		image.setIcon(new ImageIcon(CacheUnitView.class.getResource("/img.jpg")));
		ipanel.add(image);

		JPanel opanel=new JPanel();
		opanel.setBounds(0,300,1000,300);
		opanel.setBackground(mycolor3);
		ContentPane.add(opanel);
		opanel.setLayout(null);

		final JFileChooser filechooser=new JFileChooser();
		filechooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);

		JButton lrb= new JButton("Load a Request");
		lrb.addActionListener(new ActionListener() 
		{

			@Override
			public void actionPerformed(ActionEvent act) {
				JFileChooser jfc = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());

				int returnValue = jfc.showOpenDialog(null);
				

				if (returnValue == JFileChooser.APPROVE_OPTION) {
					File selectedFile = jfc.getSelectedFile();
					setChanged();
					notifyObservers(selectedFile.getAbsoluteFile().toString());
				}

			}

		});
		lrb.setVerticalTextPosition(AbstractButton.BOTTOM);
		lrb.setHorizontalTextPosition(AbstractButton.CENTER);
		lrb.setFont(f);
		lrb.setBackground(mycolor);
		lrb.setForeground(Color.WHITE);
		lrb.setBounds(50, 70, 150, 50);    

		JButton cmb=new JButton("CacheMemory");
		cmb.addActionListener(new ActionListener() 
		{

			@Override
			public void actionPerformed(ActionEvent act) {
				
				setChanged();
				notifyObservers("STATISTICS");

			}

		});
		cmb.setVerticalTextPosition(AbstractButton.BOTTOM);
		cmb.setHorizontalTextPosition(AbstractButton.CENTER);
		cmb.setFont(f);
		cmb.setBackground(mycolor);
		cmb.setForeground(Color.WHITE);
		cmb.setBounds(50, 150, 150, 50);  


		opanel.add(lrb);
		opanel.add(cmb);

		infoArea.setBackground(Color.WHITE);
		infoArea.setBounds(250, 50, 700, 170);
		infoArea.setFont(f2);
		infoArea.setEditable(false);
		infoArea.setBorder(BorderFactory.createCompoundBorder(infoArea.getBorder(), BorderFactory.createEmptyBorder(5, 5, 5, 5)));
		JScrollPane scrollPane = new JScrollPane(infoArea,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollPane.setBounds(250, 50, 700, 170);
		opanel.add(scrollPane);
		

		//Display the window
		frame.pack();
		frame.setSize(1000,600);
		frame.setVisible(true);

		setChanged();
		notifyObservers("STATISTICS");

	}




	@Override
	public <T> void updateUIData(T t) {

		infoArea.setText((String) t);
	}

}
